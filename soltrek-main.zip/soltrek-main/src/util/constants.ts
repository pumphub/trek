export const USDC_DECIMALS = 1_000_000
